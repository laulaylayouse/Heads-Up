package com.example.headsup_prep_laila

import retrofit2.Call
import retrofit2.http.*

interface APIInterface {

    @Headers("Content-Type: application/json")
    @POST("/celebrities/")
    fun addCelebrity(@Body userData: UserDetails.User): Call<List<UserDetails.User>>

    @Headers("Content-Type: application/json")
    @GET("/celebrities/")
    fun getCelebrity(): Call<List<UserDetails.User>>

    @Headers("Content-Type: application/json")
    @DELETE("/celebrities/{pk}")
    fun deleteCelebrity(@Path("pk") pk: Int ): Call<Void>

    @Headers("Content-Type: application/json")
    @PUT("/celebrities/{pk}")
    fun updateCelebrity(@Path("pk") pk : Int, @Body userData: UserDetails.User): Call<List<UserDetails.User>>
}