package com.example.headsup_prep_laila

import android.app.ProgressDialog
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Update_DeleteActivity : AppCompatActivity() {

    lateinit var textView_ID: TextView

    lateinit var EditText_add_Name: EditText
    lateinit var EditText_add_Taboo1: EditText
    lateinit var EditText_add_Taboo2: EditText
    lateinit var EditText_add_Taboo3: EditText

    lateinit var Button_Update: Button
    lateinit var Button_Delete: Button
    lateinit var Button_Back: Button

    var name_ = ""
    var taboo1 = ""
    var taboo2 = ""
    var taboo3 = ""
    private var pk_to = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update_delete)

        textView_ID = findViewById(R.id.textView_ID)

        EditText_add_Name = findViewById(R.id.EditText_add_Name)
        EditText_add_Taboo1 = findViewById(R.id.EditText_add_Taboo1)
        EditText_add_Taboo2 = findViewById(R.id.EditText_add_Taboo2)
        EditText_add_Taboo3 = findViewById(R.id.EditText_add_Taboo3)

        Button_Update = findViewById(R.id.Button_Update)
        Button_Delete = findViewById(R.id.Button_Delete)
        Button_Back = findViewById(R.id.Button_Back)

        var data = intent.extras?.getStringArrayList("Celebrity Data")
        if (data != null) {

            textView_ID.text = "ID: ${data[0]}"
            EditText_add_Name.setHint("Nmae: ${data[1]}")
            EditText_add_Taboo1.setHint("Toboo1: ${data[2]}")
            EditText_add_Taboo2.setHint("Toboo2: ${data[3]}")
            EditText_add_Taboo3.setHint("Toboo3: ${data[4]}")
        } else {
            Toast.makeText(this, "Sorry something run wrong!!".uppercase(), Toast.LENGTH_SHORT)
                .show()
        }

        pk_to = data!![0]

        Button_Delete.setOnClickListener {

            val dialogBuilder = AlertDialog.Builder(this)

            // set message of alert dialog
            dialogBuilder.setMessage("Are you sure want delete it.")
                // if the dialog is cancelable
                .setCancelable(false)
                // positive button text and action
                .setPositiveButton("Yes", DialogInterface.OnClickListener { dialog, id ->
                    this.deleteCelebrity()
                })
                // negative button text and action
                .setNegativeButton("No", DialogInterface.OnClickListener { dialog, id ->
                    dialog.cancel()
                })

            // create dialog box
            val alert = dialogBuilder.create()
            // set title for alert dialog box
            alert.setTitle("Delete Celebrity".uppercase())
            // show alert dialog
            alert.show()

        }

        Button_Update.setOnClickListener {

            name_ = EditText_add_Name.text.toString()
            taboo1 = EditText_add_Taboo1.text.toString()
            taboo2 = EditText_add_Taboo2.text.toString()
            taboo3 = EditText_add_Taboo3.text.toString()

            if(name_.isNotEmpty() && taboo1.isNotEmpty() && taboo2.isNotEmpty() && taboo3.isNotEmpty()) {

                updateCelebrity()

                Toast.makeText(applicationContext, "Celebrity is Updated".uppercase(), Toast.LENGTH_SHORT).show()

                EditText_add_Name.setText("")
                EditText_add_Taboo1.setText("")
                EditText_add_Taboo2.setText("")
                EditText_add_Taboo3.setText("")
            }

            else{

                Toast.makeText(this, "Please Enter a Information Correctly".uppercase(), Toast.LENGTH_LONG).show()

            }

        }

        Button_Back.setOnClickListener {

            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)

        }

    }

        private fun updateCelebrity() {

        val apiInterface = APIClient().getClient()?.create(APIInterface::class.java)
        val progressDialog = ProgressDialog(this)
        progressDialog.setMessage("Please wait")
        progressDialog.show()
        apiInterface?.updateCelebrity(pk_to.toInt(),UserDetails.User(name_, pk_to.toInt(), taboo1, taboo2, taboo3))?.enqueue(object :
            Callback<List<UserDetails.User>> {
            override fun onResponse(
                call: Call<List<UserDetails.User>>,
                response: Response<List<UserDetails.User>>,
            ) {
                Toast.makeText(applicationContext, "Celebrity Updated Successfully!".uppercase(), Toast.LENGTH_SHORT).show()
                response.body()
                progressDialog.dismiss()
            }

            override fun onFailure(call: Call<List<UserDetails.User>>, t: Throwable) {
                progressDialog.dismiss()
                call.cancel()
            }

        })


    }

    private fun deleteCelebrity() {
        val apiInterface = APIClient().getClient()?.create(APIInterface::class.java)
        val progressDialog = ProgressDialog(this)
        progressDialog.setMessage("Please wait")
        progressDialog.show()
        apiInterface?.deleteCelebrity(pk_to.toInt())?.enqueue(object : Callback<Void> {
            override fun onResponse(call: Call<Void>, response: Response<Void>) {
                Toast.makeText(
                    applicationContext,
                    "Celebrity is  deleted".uppercase(),
                    Toast.LENGTH_SHORT
                ).show()
                response.body()
                progressDialog.dismiss()
            }

            override fun onFailure(call: Call<Void>, t: Throwable) {
                progressDialog.dismiss()
                call.cancel()

            }
        })
    }
}