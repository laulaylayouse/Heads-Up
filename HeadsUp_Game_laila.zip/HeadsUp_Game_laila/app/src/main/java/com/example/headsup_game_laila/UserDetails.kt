package com.example.headsup_game_laila

import com.google.gson.annotations.SerializedName


class UserDetails {

    var data: ArrayList<User>? = null

    class User {
        @SerializedName("name")
        var name: String? = null

        @SerializedName("pk")
        var pk: Int? = null

        @SerializedName("taboo1")
        var taboo1: String? = null

        @SerializedName("taboo2")
        var taboo2: String? = null

        @SerializedName("taboo3")
        var taboo3: String? = null

        constructor(name: String?, pk: Int?, taboo1: String?, taboo2: String?, taboo3: String?) {

            this.name = name
            this.pk = pk
            this.taboo1 = taboo1
            this.taboo2 = taboo2
            this.taboo3 = taboo3
        }
    }
}