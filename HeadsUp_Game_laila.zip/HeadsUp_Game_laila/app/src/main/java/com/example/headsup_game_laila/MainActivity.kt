package com.example.headsup_game_laila

import android.app.ProgressDialog
import android.content.Intent
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.TextView
import androidx.core.view.isVisible
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import kotlin.random.Random

class MainActivity : AppCompatActivity() {


    lateinit var TextView_Name : TextView
    lateinit var TextView_Toboo1 :TextView
    lateinit var TextView_Toboo2 :TextView
    lateinit var TextView_Toboo3 :TextView
    lateinit var TextView :TextView

    lateinit var Button_start: Button

    var timer=60000L


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        title="Timer:--"

        val apiInterface = APIClient().getClient()?.create(APIInterface::class.java)
        val rotation= resources.configuration.orientation

        if(rotation== Configuration.ORIENTATION_LANDSCAPE){
            TextView_Name=findViewById(R.id.TextView_Name)
            TextView_Toboo1=findViewById(R.id.TextView_Toboo1)
            TextView_Toboo2=findViewById(R.id.TextView_Toboo2)
            TextView_Toboo3=findViewById(R.id.TextView_Toboo3)

            val progressDialog = ProgressDialog(this)
            progressDialog.setMessage("Please wait".uppercase())
            progressDialog.show()
            apiInterface!!.getCelebrity().enqueue(object: Callback<List<UserDetails.User>>{

                override fun onResponse(
                    call: Call<List<UserDetails.User>>,
                    response: Response<List<UserDetails.User>>
                ) {
                    progressDialog.dismiss()
                    countTimer()
                    val list = response.body()!!
                    randomFun(list)
                }

                override fun onFailure(call: Call<List<UserDetails.User>>, t: Throwable) {
                    call.cancel()
                    progressDialog.dismiss()
                }
            })


        }
        else{

            TextView=findViewById(R.id.TextView)

            Button_start = findViewById(R.id.Button_start)
            Button_start.isVisible=true
            TextView.isVisible=true

            Button_start.setOnClickListener {
                TextView.text="Rotate The Device ! "
                Button_start.isVisible=false

            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putLong("Timer", timer)

    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        timer= savedInstanceState.getLong("Timer", 60000L)
        title= "Timer:${timer / 1000}"
        countTimer()
    }

    private fun countTimer(){

        object: CountDownTimer(timer, 1000) {

            override fun onTick(millisUntilFinished: Long) {
                timer = millisUntilFinished
                title = "Timer ${timer / 1000}"
            }

            override fun onFinish() {
                title="TIME IS OUT!"

            }
        }.start()


    }
    fun randomFun(list: List<UserDetails.User>){

        var random = Random.nextInt(0,list.size)

        var randomobject = list[random]
        TextView_Name.text= randomobject.name
        TextView_Toboo1.text=randomobject.taboo1
        TextView_Toboo2.text=randomobject.taboo2
        TextView_Toboo3.text=randomobject.taboo3

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.Add_celebrity -> {
                val intent = Intent(this, AddActivity::class.java)
                startActivity(intent)
                return true
            }

            R.id.View_celebrity -> {
                val intent = Intent(this, ViewActivity::class.java)
                startActivity(intent)
                return true
            }

            R.id.refresh -> {
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}