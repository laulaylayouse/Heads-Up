package com.example.headsup_game_laila

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ViewActivity : AppCompatActivity() {

    var Celebrity_List = arrayListOf<UserDetails.User>()
    var check_Name = ""

    lateinit var RecyclerView : RecyclerView
    lateinit var Button_Add: Button
    lateinit var Button_search: Button
    lateinit var EditText_Name: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view)

        RecyclerView = findViewById(R.id.Recycler_View)
        RecyclerView.adapter =Adapter(Celebrity_List)
        RecyclerView.layoutManager = LinearLayoutManager(this)

        EditText_Name = findViewById(R.id.EditText_Name)
        Button_Add = findViewById(R.id.Button_Add)
        Button_search = findViewById(R.id.Button_search)

        RecyclerView.adapter?.notifyDataSetChanged()

        getCelebrities()

        Button_Add.setOnClickListener {

            val progressDialog = ProgressDialog(this)
            progressDialog.setMessage("Please wait".uppercase())
            progressDialog.show()

            val intent = Intent(this, AddActivity::class.java)
            startActivity(intent)


        }

        Button_search.setOnClickListener {

            var searchItem : UserDetails.User? = null
            check_Name = EditText_Name.text.toString()

            for ( i in Celebrity_List){
                if (check_Name == i.name){
                    searchItem = i
                    break
                }
            }
            if (searchItem != null){
                val intent = Intent(this, Update_DeleteActivity::class.java)
                intent.putStringArrayListExtra("Celebrity Data", arrayListOf(
                        searchItem.pk.toString(),searchItem.name,searchItem.taboo1,
                        searchItem.taboo2,searchItem.taboo3))
                Toast.makeText(this, "Celebrity Is Exist IN Our List".uppercase(), Toast.LENGTH_SHORT).show()

                startActivity(intent)
            }else {
                Toast.makeText(this, "Celebrity Is not Exist IN Our List".uppercase(), Toast.LENGTH_SHORT).show()

            }

        }


    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.game_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.Game -> {
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun getCelebrities() {
        val apiInterface = APIClient().getClient()?.create(APIInterface::class.java)
        val progressDialog = ProgressDialog(this)
        progressDialog.setMessage("Please wait".uppercase())
        progressDialog.show()

        apiInterface?.getCelebrity()?.enqueue(object : Callback<List<UserDetails.User>> {


            override fun onResponse(
                call: Call<List<UserDetails.User>>,
                response: Response<List<UserDetails.User>>,
            ) {
                val resource = response.body()!!
                progressDialog.dismiss()
                for (i in resource) {
                    var pk = i.pk?.toInt()
                    var Name = i.name.toString()
                    var Taboo1 = i.taboo1.toString()
                    var Taboo2 = i.taboo2.toString()
                    var Taboo3 = i.taboo3.toString()
                    Celebrity_List.add(UserDetails.User(Name, pk, Taboo1, Taboo2, Taboo3))

                }
                RecyclerView.adapter?.notifyDataSetChanged()
            }

            override fun onFailure(call: Call<List<UserDetails.User>>, t: Throwable) {

                progressDialog.dismiss()
                call.cancel()

            }
        })

    }
}