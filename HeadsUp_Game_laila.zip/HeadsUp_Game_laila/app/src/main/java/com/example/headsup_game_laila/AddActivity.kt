package com.example.headsup_game_laila

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AddActivity : AppCompatActivity() {

    lateinit var EditText_add_Name : EditText
    lateinit var EditText_add_Taboo1 : EditText
    lateinit var EditText_add_Taboo2 : EditText
    lateinit var EditText_add_Taboo3 : EditText

    lateinit var Button_Save : Button
    lateinit var Button_Back : Button

    var name =""
    var taboo1 =""
    var taboo2 =""
    var taboo3 =""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)

        EditText_add_Name = findViewById(R.id.EditText_add_Name)
        EditText_add_Taboo1 = findViewById(R.id.EditText_add_Taboo1)
        EditText_add_Taboo2 = findViewById(R.id.EditText_add_Taboo2)
        EditText_add_Taboo3 = findViewById(R.id.EditText_add_Taboo3)

        Button_Save = findViewById(R.id.Button_Save)
        Button_Back = findViewById(R.id.Button_Back)

        Button_Save.setOnClickListener {

            name = EditText_add_Name.text.toString()
            taboo1 = EditText_add_Taboo1.text.toString()
            taboo2 = EditText_add_Taboo2.text.toString()
            taboo3 = EditText_add_Taboo3.text.toString()

            if(name.isNotEmpty() && taboo1.isNotEmpty() && taboo2.isNotEmpty() && taboo3.isNotEmpty()) {

                addCelebrity()

                Toast.makeText(applicationContext, "New Celebrity is Added".uppercase(), Toast.LENGTH_SHORT).show()

                EditText_add_Name.setText("")
                EditText_add_Taboo1.setText("")
                EditText_add_Taboo2.setText("")
                EditText_add_Taboo3.setText("")
            }

            else{

                Toast.makeText(this, "Please Enter a Information Correctly".uppercase(), Toast.LENGTH_LONG).show()

            }

        }

        Button_Back.setOnClickListener {

            val intent = Intent(this, ViewActivity::class.java)
            startActivity(intent)

        }


    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.game_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.Game -> {
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun addCelebrity() {
        val apiInterface = APIClient().getClient()?.create(APIInterface::class.java)
        val progressDialog = ProgressDialog(this)
        progressDialog.setMessage("Please wait".uppercase())
        progressDialog.show()

        apiInterface?.addCelebrity(UserDetails.User(name, pk = null,taboo1,taboo2,taboo3))
            ?.enqueue(object : Callback<List<UserDetails.User>> {
                override fun onResponse(
                    call: Call<List<UserDetails.User>>,
                    response: Response<List<UserDetails.User>>,
                ) {

                    Toast.makeText(applicationContext, "New Celebrity is Added".uppercase() , Toast.LENGTH_SHORT).show()
                    progressDialog.dismiss()

                }

                override fun onFailure(
                    call: Call<List<UserDetails.User>>,
                    t: Throwable,
                ) {
                    progressDialog.dismiss()
                    call.cancel()
                }

            })

    }
}